<?php
include("biblioteca.php");

cabecera("Inicio", MENU_PRINCIPAL, CABECERA_SIN_CURSOR);

?>
