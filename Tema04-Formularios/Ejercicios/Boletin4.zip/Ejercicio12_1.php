<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Ejercicio 12
  </title>
  <link rel="stylesheet" href="css/style.css" title="Color">
</head>

<body>
  <h1>Ejercicio 12</h1>

  <form action="Ejercicio12_2.php" method="get">
    <p>Escriba su nombre: <input type="text" name="nombre" size="20" maxlength="20"></p>

    <p>Escriba sus apellidos: <input type="text" name="apellidos" size="40" maxlength="40"></p>

    <p>
      <input type="submit" value="Enviar">
      <input type="reset" value="Borrar">
    </p>
  </form>

</body>
</html>
