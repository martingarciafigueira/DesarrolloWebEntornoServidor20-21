<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Ejercicio 16
  </title>
  <link rel="stylesheet" href="css/style.css" title="Color">
</head>

<body>
  <h1>Ejercicio 16</h1>

  <form action="Ejercicio16_2.php" method="get">
    <p>Tamaño del cuadrado: <input type="number" name="lado" min="20" max="500" value="100"></p>

    <p>Tamaño de la esquina redondeada: <input type="number" name="esquina" min="10" max="250" value="20"></p>

    <p>
      <input type="submit" value="Enviar">
      <input type="reset" value="Borrar">
    </p>
  </form>
</body>
</html>
