<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Ejercicio 10
  </title>
  <link rel="stylesheet" href="css/style.css" title="Color">
</head>

<body>
  <h1>Ejercicio 10</h1>

  <form action="Ejercicio10_2.php" method="get">
    <p>Elija los colores a cambiar:<br> Color de fondo de la página: <input type="color" name="fondo" value="#ffffff"><br> Color de la letra de la página: <input type="color" name="letra" value="#000000">
    </p>

    <p>
      <input type="submit" value="Enviar">
      <input type="reset" value="Borrar">
    </p>
  </form>
</body>
</html>
