<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Ejercicio 7
  </title>
  <link rel="stylesheet" href="css/style.css" title="Color">
</head>

<body>
  <h1>Ejercicio 7</h1>

  <form action="Ejercicio7_2.php" method="get">
    <p>Indique su fruta preferida:<br>
      <label><input type="radio" name="fruta" value="cerezas.svg"> Cerezas</label><br>
      <label><input type="radio" name="fruta" value="fresa.svg"> Fresas</label><br>
      <label><input type="radio" name="fruta" value="limon.svg"> Limón</label><br>
      <label><input type="radio" name="fruta" value="manzana.svg"> Manzana</label><br>
      <label><input type="radio" name="fruta" value="naranja.svg"> Naranja</label><br>
      <label><input type="radio" name="fruta" value="pera.svg"> Pera</label>
    </p>

    <p>
      <input type="submit" value="Enviar">
      <input type="reset" value="Borrar">
    </p>
  </form>
</body>
</html>
