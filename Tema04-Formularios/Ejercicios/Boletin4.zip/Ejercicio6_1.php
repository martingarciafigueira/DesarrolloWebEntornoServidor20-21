<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Ejercicio 6
  </title>
  <link rel="stylesheet" href="css/style.css" title="Color">
</head>

<body>
  <h1>Ejercicio 6</h1>

  <form action="Ejercicio6_2.php" method="get">
    <p>Indique su fruta preferida:<br>
      <label><input type="radio" name="fruta" value="las cerezas"> Cerezas</label><br>
      <label><input type="radio" name="fruta" value="la fresa"> Fresas</label><br>
      <label><input type="radio" name="fruta" value="el limón"> Limón</label><br>
      <label><input type="radio" name="fruta" value="la manzana"> Manzana</label><br>
      <label><input type="radio" name="fruta" value="la naranja"> Naranja</label><br>
      <label><input type="radio" name="fruta" value="la pera"> Pera</label>
    </p>

    <p>
      <input type="submit" value="Enviar">
      <input type="reset" value="Borrar">
    </p>
  </form>
</body>
</html>
