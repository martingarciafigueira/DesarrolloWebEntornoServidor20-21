<?php header( "Refresh: 10; url=http://www.google.es" ); ?>
<html>
 <head>
  <title>Tarefa 2b</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
 </head>
 <body>
  <p style='text-align: center;'>Se le va a redireccionar a 
    <a href="http://www.google.es">www.google.es</a> en 10 segundos.</p>
 </body>
</html>
