<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Ejercicio 13
  </title>
  <link rel="stylesheet" href="css/style.css" title="Color">
</head>

<body>
  <h1>Ejercicio 13</h1>

  <form action="Ejercicio13_2.php" method="get">
    <p>Escriba su edad: <input type="number" name="edad" min="5" max="130"></p>
    <p>Escriba su peso: <input type="number" name="peso" step="0.1" min="10" max="150"></p>

    <p>
      <input type="submit" value="Enviar">
      <input type="reset" value="Borrar">
    </p>
  </form>
</body>
</html>
