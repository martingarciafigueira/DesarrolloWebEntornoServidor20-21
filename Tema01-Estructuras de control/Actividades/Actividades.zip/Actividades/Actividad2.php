<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $nombre = "Cosi";
        $edad = 22;
        $_AsisteAClase = true;
               
        echo 'Hola'.' '.'a todos!';
        
        echo 2 + 2 == 4;
        
        echo 'Acuña crack';
        
        ?>
    </body>
</html>
