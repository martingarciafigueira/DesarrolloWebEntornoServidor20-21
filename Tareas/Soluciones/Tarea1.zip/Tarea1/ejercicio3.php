<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    <function>

    </function>
</head>
<body>
    <?php
    //Creo un array vacío con la cuadrícula
    $cuadricula = array();

    //Lleno la cuadrícula entera de puntos
    for ($i = 0; $i < 20; $i++) {
        for ($j = 0; $j < 20; $j++) {
            $cuadricula[$i][$j] = '.';
        }
    }

    //Pongo las minas
    $mina = 0;
    do {
        $x = rand(0, 19);
        $y = rand(0, 19);
        if ($cuadricula[$x][$y] == '.') {
            $cuadricula[$x][$y] = '*';
            $mina++;
        }
    } while ($mina < 10);

    //Pinto la cuadricula con las minas
    for ($i = 0; $i < 20; $i++) {
        for ($j = 0; $j < 20; $j++)
            echo $cuadricula[$i][$j] . '  ';
        echo '<br/>';
    }
    ?>
    <form action="">
        <!-- Hago que el botón btnColocarMinas me recargue la página, así seleccionaré 10 minas nuevas al azar y se colocarán en la cuadrícula !-->
        <input type="submit" id="btnColocarMinas" value="Colocar minas">
    </form>

    <?php
    //Pinto las posiciones en las que hay minas
    for ($i = 0; $i < 20; $i++) {
        for ($j = 0; $j < 20; $j++) {
            if ($cuadricula[$i][$j] == '*') {
                echo "<p>POSICION:" . ($i + 1) . " " . ($j + 1) . "</p>";
            }
        }
    }

    ?>
</body>
</html>
