<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Document</title>
    </head>
    <body>
        <?php
        //Creamos la baraja usando matrices
        $palo = array('oros', 'bastos', 'espadas', 'copas');
        $figura = array('as', 'dos', 'tres', 'cuatro', 'cinco', 'seis', 'siete', 'sota', 'caballo', 'rey');
        $baraja = array(40);
        //==================================
        //llenamos la baraja
        //==================================
        $p = 0;
        for ($i = 0; $i < 4; $i++) {

            for ($x = 0; $x < 10; $x++) {
                if ($p < 40) {
                    $baraja[$p] = $figura[$x] . " de " . $palo[$i];
                }
                $p++;
            }
        }

        echo "<p>";
        echo "Baraja ordenada: </br>";
        foreach ($baraja as $carta) {
            echo " $carta <br/>";
        }
        echo "</p>";

        echo "<p>";
        echo "Baraja desordenada: </br>";
        shuffle($baraja);
        foreach ($baraja as $carta) {
            echo " $carta <br/>";
        }
        echo "</p>";
        ?>

    </body>
</html>
