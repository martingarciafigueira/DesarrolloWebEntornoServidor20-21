<?php

$tabla_multiplicar = 9;

echo "<p>Tabla de multiplicar del ".$tabla_multiplicar."</p>";
for($i=1;$i<=10;$i++)
{
    $cuenta_parcial = $tabla_multiplicar * $i;
    echo "<p>".$tabla_multiplicar." x ".$i." = ".$cuenta_parcial."</p>";
}
