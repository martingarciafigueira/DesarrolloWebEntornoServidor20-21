<?php

$numeros = array(1,2,3,4,5);
$sumaTotal = 0;

echo "<p>";
echo "Los valores introducidos son: ";
foreach ($numeros as $numero) {
    print "$numero ";
}
echo "</p>";

echo "<p>";
echo "La suma de los valores es: ";
foreach ($numeros as $numero) {
    $sumaTotal += $numero;
}
echo $sumaTotal;
echo "</p>";

echo "<p>";
echo "La media de los valores es: ";
$media = $sumaTotal / count($numeros);
echo $media;
echo "</p>";

echo "<p>";
echo "El valor más grande es: ";
$max = max($numeros);
echo $max;
echo "</p>";

echo "<p>";
echo "El valor más pequeño es: ";
$min = min($numeros);
echo $min;
echo "</p>";



